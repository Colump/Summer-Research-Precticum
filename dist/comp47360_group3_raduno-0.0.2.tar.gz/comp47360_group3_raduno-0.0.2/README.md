# COMP47360_Group3_Raduno

COMP47360 Research Practicum project for Team 3, "Raduno"